#pragma once

struct sLocalPlayer 
{
	//Todo Reclass the classes
	DWORD_PTR LocalPlayerController = 0;
	DWORD_PTR pLocalPlayerCameraManager = 0;

	int TeamNumber = 0;
};
